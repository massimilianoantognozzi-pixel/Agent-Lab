import hashlib, json, urllib.request
from pathlib import Path
base = Path(__file__).resolve().parent
m = json.loads((base/'model-manifest.json').read_text())
for f in m['files']:
    dest = base/'model'/f['file']
    dest.parent.mkdir(parents=True, exist_ok=True)
    url = 'https://huggingface.co/'+m['repository']+'/resolve/'+m['revision']+'/'+f['file']
    with urllib.request.urlopen(url, timeout=90) as resp:
        payload = resp.read()
    assert len(payload)==f['bytes'] and hashlib.sha256(payload).hexdigest()==f['sha256'], f['file']
    dest.write_bytes(payload)
