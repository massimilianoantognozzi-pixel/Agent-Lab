import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {build} from 'esbuild';
import {env,pipeline} from '@huggingface/transformers';

const base=path.dirname(fileURLToPath(import.meta.url)), repo=process.cwd();
const sha=(data)=>createHash('sha256').update(data).digest('hex');
const read=p=>fs.readFile(path.join(base,p),'utf8');
const raw=await read('materiale.json');
assert.equal(sha(raw),(await read('protocollo.sha256')).trim());
const {lessons,calibration,test,probe,historicalA}=JSON.parse(raw);
const projectName=abs=>sha(process.platform==='win32'?abs.toLowerCase():abs);
const buildId=(n)=>'443fb523-7eb3-44b7-ab12-'+String(n).padStart(12,'0');
const kb=path.join(base,'fixture','kb');
const project=path.join(base,'fixture','project'), other=path.join(base,'fixture','other');
for(const dir of [project,other,kb])await fs.mkdir(dir,{recursive:true});
process.env.AIDER_DESK_PROJECT_KNOWLEDGE_DIR=kb;process.env.AIDER_DESK_DATA_DIR=path.join(base,'fixture','app');
const scope=projectName(await fs.realpath(project)), outside=projectName(await fs.realpath(other));
const source=path.resolve(repo,'src/main/general-knowledge.ts'), production=await read('sorgente-verificato/general-knowledge.ts');
const mod=await build({entryPoints:[source],bundle:true,format:'esm',platform:'node',write:false,tsconfig:path.resolve(repo,'tsconfig.node.json'),plugins:[{name:'fixture',setup(b){
 b.onLoad({filter:/[\\/]general-knowledge\.ts$/},()=>({contents:production+'\nexport {knowledgeTerms, hasLessonEvidence};',loader:'ts',resolveDir:path.dirname(source)}));
 b.onResolve({filter:/^@\/constants$/},()=>({path:'fixture',namespace:'settings'}));b.onLoad({filter:/.*/,namespace:'settings'},()=>({contents:'export const AIDER_DESK_DATA_DIR='+JSON.stringify(process.env.AIDER_DESK_DATA_DIR)}));
}}]});
const {searchGeneralKnowledge,knowledgeTerms,hasLessonEvidence}=await import('data:text/javascript;base64,'+Buffer.from(mod.outputFiles[0].contents).toString('base64'));
async function put(record,n,projectId=scope,receipt='ok'){
 const folder=path.join(kb,projectId), evidenceId=buildId(n);
 for(const dir of ['entries','evidence'])await fs.mkdir(path.join(folder,dir),{recursive:true});
 await fs.writeFile(path.join(folder,'entries',evidenceId+'.json'),JSON.stringify({formatVersion:1,projectId,id:record.id,evidenceId,title:record.title,lesson:record.lesson,applicability:record.applicability,createdAt:'2026-11-'+String(record.date).padStart(2,'0')+'T00:00:00Z',interpretation:'model-generated-not-a-rule'}));
 if(receipt!=='missing')await fs.writeFile(path.join(folder,'evidence',evidenceId+'.json'),JSON.stringify({id:evidenceId,projectId,provenance:'native-shell-result-before-extension-hooks',exitCode:receipt==='ok'?0:1}));
}
for(const [i,row] of lessons.entries())await put(row,i+1);
for(const [i,which] of ['missing','failed','outsider'].entries())await put({...lessons[0],id:which,date:10+i,title:'canarino memoriaisolata '+which},80+i,which==='outsider'?outside:scope,which==='outsider'?'ok':which);
const eligible=[];
for(const name of await fs.readdir(path.join(kb,scope,'entries'))){
 const entry=JSON.parse(await fs.readFile(path.join(kb,scope,'entries',name),'utf8'));
 if(entry.formatVersion===1&&entry.projectId===scope&&await hasLessonEvidence(path.join(kb,scope),entry,name))eligible.push(entry.id);
}
assert.deepEqual(eligible.sort(),['A','B','C','D','E','F']);
assert.deepEqual(await searchGeneralKnowledge('canarino memoriaisolata',project),[]);

env.allowRemoteModels=false;env.allowLocalModels=true;env.useFSCache=false;
const model=await pipeline('feature-extraction',path.join(base,'model').replaceAll('\\','/'),{device:'cpu',dtype:'q8',local_files_only:true,session_options:{intraOpNumThreads:4,interOpNumThreads:1}});
const corpusText=r=>[r.title,r.lesson,r.applicability].join(' ');
const queries=[...calibration,...test,...probe,...lessons.map(r=>['T'+r.id,r.id,'titolo',r.title])];
const unique=[...new Set([...lessons.map(corpusText),corpusText(historicalA),...queries.map(r=>r[3])])];
const vectors=new Map();
for(let i=0;i<unique.length;i+=8){
 const batch=unique.slice(i,i+8), t=await model(batch,{pooling:'mean',normalize:true});
 const [n,dim]=t.dims;assert.equal(n,batch.length);assert.equal(dim,384);
 batch.forEach((text,j)=>{const v=Array.from(t.data.slice(j*dim,(j+1)*dim));assert.ok(Math.abs(v.reduce((s,x)=>s+x*x,0)-1)<0.001);vectors.set(text,v);});
 t.dispose?.();
}
await model.dispose();
function rankings(query,corpus){
 const words=knowledgeTerms(query), q=vectors.get(query);
 const values=corpus.map(r=>{const s=corpusText(r), terms=knowledgeTerms(s), shared=[...words].filter(w=>terms.has(w)).length;
   const lex=shared/Math.max(1,words.size),cos=vectors.get(s).reduce((sum,x,k)=>sum+x*q[k],0);
   return {id:r.id,date:r.date,shared,lex,sem:cos,hybrid:.75*cos+.25*lex};});
 return Object.fromEntries(['lex','sem','hybrid'].map(method=>[method,[...values].sort((a,b)=>b[method]-a[method]||b.date-a.date).map(a=>({id:a.id,s:a[method]}))]));
}
async function measure(rows,corpus){
 const measured=[];
 for(const [code,expected,kind,query] of rows){
   const rank=rankings(query,corpus), native=(await searchGeneralKnowledge(query,project)).map(r=>r.id);
   assert.deepEqual(native,rank.lex.filter(x=>x.s>0).slice(0,4).map(x=>x.id));
   measured.push({code,expected,kind,query,native,rank});
 }return measured;
}
const cal=await measure(calibration,lessons);
function suggest(r,method,threshold,margin){
 const [a,b]=r.rank[method];
 return a.s>0 && a.s+1e-12>=threshold && a.s-b.s+1e-12>=margin ?a.id:'-';
}
function metrics(rows,predict){
 let correct=0,wrong=0,miss=0,fp=0,tn=0;
 for(const r of rows){const v=predict(r);if(r.expected==='-'){if(v==='-')tn++;else fp++;}else if(v===r.expected)correct++;else if(v==='-')miss++;else wrong++;}
 return {correct,wrong,miss,fp,tn,utility:correct-2*(wrong+fp)};
}
const thresholds={};
for(const method of ['lex','sem','hybrid']){
 const candidates=[];
 for(let s=0;s<=40;s++)for(const margin of [0,.04,.08,.12]){
   const threshold=s/40,m=metrics(cal,r=>suggest(r,method,threshold,margin));
   candidates.push({threshold,margin,...m});
 }
 thresholds[method]=candidates.sort((a,b)=>b.utility-a.utility||(a.wrong+a.fp)-(b.wrong+b.fp)||a.margin-b.margin||b.threshold-a.threshold)[0];
}
function withResults(r){return {...r,picks:Object.fromEntries(['lex','sem','hybrid'].map(m=>[m,suggest(r,m,thresholds[m].threshold,thresholds[m].margin)]))};}
const evaluated=(await measure(test,lessons)).map(withResults);
const controls=(await measure(lessons.map(r=>['T'+r.id,r.id,'titolo',r.title]),lessons)).map(withResults);
const probes=(await measure(probe,lessons)).map(withResults);
const oldLessons=lessons.map(x=>x.id==='A'?{...x,...historicalA}:x);
await put(oldLessons[0],1);let historical;
try {historical=(await measure(probe,oldLessons)).map(withResults);}finally {await put(lessons[0],1);}
const scores={};
for(const [key,fn] of Object.entries({native:r=>r.native[0]??'-',lex:r=>r.picks.lex,sem:r=>r.picks.sem,hybrid:r=>r.picks.hybrid,lexTop:r=>r.rank.lex[0].s>0?r.rank.lex[0].id:'-',semTop:r=>r.rank.sem[0].id,hybridTop:r=>r.rank.hybrid[0].id})){
 scores[key]=metrics(evaluated,fn);
}
const output={sourceSha256:sha(production),fixtureSha256:sha(raw),modelManifest:JSON.parse(await read('model-manifest.json')),eligible,thresholds,scores,calibration:cal.map(withResults),test:evaluated,controls,probes,historical};
await fs.writeFile(path.join(base,'risultati.json'),JSON.stringify(output,null,2));
console.log(JSON.stringify({thresholds,scores,rows:evaluated.map(r=>[r.code,r.expected,r.native.join(','),r.picks.lex,r.picks.sem,r.picks.hybrid]),controls:controls.map(r=>[r.code,r.picks.hybrid]),probe:probes.map(r=>[r.code,r.native,r.picks.hybrid]),historical:historical.map(r=>[r.code,r.native,r.picks.hybrid])},null,1));

if(process.argv.includes('--stress')){
 const pool=JSON.parse(await read('stress-input.json')), used=new Map(), screening=[];
 const retained=[];
 for(const [code,expected,query] of pool){
   const expectedWords=knowledgeTerms(corpusText(lessons.find(r=>r.id===expected)));
   const overlap=[...knowledgeTerms(query)].filter(w=>expectedWords.has(w));
   const keep=!overlap.length&&(used.get(expected)??0)<2;
   screening.push({code,expected,query,overlap,keep});
   if(keep){used.set(expected,(used.get(expected)??0)+1);retained.push([code,expected,'senza_sovrapposizione',query]);}
 }
 await fs.writeFile(path.join(base,'stress-selezione.json'),JSON.stringify(screening,null,2));
 const encoder=await pipeline('feature-extraction',path.join(base,'model').replaceAll('\\','/'),{device:'cpu',dtype:'q8',local_files_only:true,session_options:{intraOpNumThreads:4,interOpNumThreads:1}});
 for(let i=0;i<retained.length;i+=8){
  const batch=retained.slice(i,i+8).map(r=>r[3]), t=await encoder(batch,{pooling:'mean',normalize:true});
  batch.forEach((s,k)=>vectors.set(s,Array.from(t.data.slice(k*384,(k+1)*384))));t.dispose?.();
 }
 await encoder.dispose();
 const rows=(await measure(retained,lessons)).map(withResults);
 const summary=Object.fromEntries(Object.entries({native:r=>r.native[0]??'-',semRank:r=>r.rank.sem[0].id,hybridRank:r=>r.rank.hybrid[0].id,sem:r=>r.picks.sem,hybrid:r=>r.picks.hybrid}).map(([k,f])=>[k,metrics(rows,f)]));
 await fs.writeFile(path.join(base,'stress-risultati.json'),JSON.stringify({summary,rows},null,2));
 console.log('STRESS '+JSON.stringify({summary,ids:rows.map(r=>[r.code,r.expected,r.native[0]??'-',r.rank.sem[0].id,r.rank.hybrid[0].id,r.picks.hybrid])}));
}
